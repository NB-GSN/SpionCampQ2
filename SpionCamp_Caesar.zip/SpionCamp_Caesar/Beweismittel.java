/**
 * SpionCamp "Tatort Schulnetz" - abgefangene Nachrichten aus den Protokollen des Schulservers.
 *
 * So benutzt ihr ein Beweisstueck in BlueJ:
 *   Ein Caesar-Objekt erzeugen, dann z. B. entschluesselnText aufrufen und als
 *   Parameter  Beweismittel.NACHRICHT_2  eintragen.
 */
public class Beweismittel
{
    /** Mission 1: Chatnachricht aus dem Firewall-Protokoll (Caesar, Schluessel unbekannt). */
    public static final String NACHRICHT_1 =
        "ZODQ SDVVZRUW JHIXQGHQ";

    /** Mission 2: Chatnachricht vom Freitag (Caesar). Auf einem Notizzettel stand: k = 7 */
    public static final String NACHRICHT_2 =
        "HT MYLPAHN ZALSSLU DPY PT SLOYLYGPTTLY LPU LPNLULZ DSHU TPA KLT UHTLU ZJOBSL NHZA HBM";

    /** Mission 2, Experte: zweite Nachricht vom Freitag (Caesar, Schluessel unbekannt). */
    public static final String NACHRICHT_2_EXPERTE =
        "EXAKDKTXYMX DEBVDXG CXWX SXKMBYBDTMLPTKGNGZ PXZ";

    /** Mission 3: lange Nachricht vom Samstag (Caesar, Schluessel unbekannt). */
    public static final String NACHRICHT_3 =
        "FYDPCP NLPDLC YLNSCTNSEPY DTYO KF FYDTNSPC HPYY OTP DNSFWP OTP WZROLEPTPY OPD DPCGPCD "
      + "WTPDE VLYY DTP UPOP YLNSCTNSE TY HPYTRPY XTYFEPY PYEDNSWFPDDPWY OPDSLWM HPNSDPWY HTC LM "
      + "DZQZCE KF GTRPYPCP OPY RPSPTXPY DNSWFPDDPW DPYOP TNS OTC SPFEP LMPYO APC XLTW WZPDNSP "
      + "OTP XLTW DZQZCE YLNS OPX WPDPY";

    /** Mission 4: Vigenere-Nachricht vom Samstag. Schluessel aus der Mail: ROUTER */
    public static final String NACHRICHT_4 =
        "WOFLGYVG JHVKRZ CLX FEZCGI";

    /** Transferaufgabe: lange Vigenere-Nachricht vom Sonntag. Schluessel: ROUTER */
    public static final String NACHRICHT_5 =
        "GZUG F WRZFL HRJ TUEWTYS QEEE RIZYPZVUN PMI CCYLGYVB UF QFEHUZ ECCS MIYIVB UNJ UVA HHXVEGYKZVI";
}
