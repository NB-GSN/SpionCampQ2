/**
 * SpionCamp "Tatort Schulnetz" - Mission 2: Java-Labor
 *
 * Die Klasse Caesar ver- und entschluesselt Texte mit dem Caesar-Verfahren.
 * Es werden nur Grossbuchstaben A bis Z verschoben. Leerzeichen und alle
 * anderen Zeichen bleiben unveraendert.
 *
 * So arbeitet ihr:
 *   Stufe BASIS     -> Methode verschluesseln(char, int)
 *   Stufe STANDARD  -> Methode verschluesselnText(String, int)
 *   Stufe EXPERTE   -> Methoden entschluesselnText, bruteForce, zaehleBuchstaben
 * Nach jeder Stufe: Rechtsklick auf die Klasse Pruefstand und die passende
 * Methode pruefeBasis(), pruefeStandard() oder pruefeExperte() aufrufen.
 *
 * @author Forensik-Team ...........
 * @version 1.0
 */
public class Caesar
{
    // ===================== Stufe BASIS =====================

    /**
     * Verschiebt einen einzelnen Grossbuchstaben um k Stellen im Alphabet.
     * Beispiel: verschluesseln('H', 3) liefert 'K', verschluesseln('Z', 3) liefert 'C'.
     *
     * @param c ein Grossbuchstabe von 'A' bis 'Z'
     * @param k der Schluessel, eine Zahl von 0 bis 25
     * @return der verschluesselte Buchstabe
     */
    public char verschluesseln(char c, int k)
    {
        int nummer = c - 'A';     // macht aus dem Buchstaben eine Zahl: 'A' -> 0, 'B' -> 1, ... 'Z' -> 25

        int neueNummer = 0;       // TODO BASIS: Ersetze die 0. Verschiebe die Nummer um k.
                                  // Achtung: Nach 'Z' (25) muss es wieder bei 'A' (0) weitergehen!

        return (char) ('A' + neueNummer);   // macht aus der Zahl wieder einen Buchstaben
    }

    // ===================== Stufe STANDARD =====================

    /**
     * Verschluesselt einen ganzen Text mit dem Schluessel k.
     * Grossbuchstaben werden verschoben, Leerzeichen und andere Zeichen bleiben gleich.
     * Beispiel: verschluesselnText("INFORMATIK", 3) liefert "LQIRUPDWLN".
     *
     * @param text der Klartext in Grossbuchstaben
     * @param k der Schluessel von 0 bis 25
     * @return der Geheimtext
     */
    public String verschluesselnText(String text, int k)
    {
        // TODO STANDARD: Gehe den Text Zeichen fuer Zeichen durch.
        // Nuetzlich: text.length(), text.charAt(i), die Methode verschluesseln(...)
        // Ein Zeichen ist ein Grossbuchstabe, wenn gilt: zeichen >= 'A' && zeichen <= 'Z'

        return "";
    }

    // ===================== Stufe EXPERTE =====================

    /**
     * Entschluesselt einen Geheimtext, wenn der Schluessel k bekannt ist.
     * Tipp: Ihr braucht keine neue Rechnung. Um wie viel muss man weiterschieben,
     * damit man insgesamt einmal "rundherum" ist?
     *
     * @param geheimtext der Geheimtext
     * @param k der Schluessel, mit dem verschluesselt wurde
     * @return der Klartext
     */
    public String entschluesselnText(String geheimtext, int k)
    {
        // TODO EXPERTE
        return "";
    }

    /**
     * Brute-Force-Angriff: Gibt fuer jeden moeglichen Schluessel von 1 bis 25
     * eine Zeile auf der Konsole aus, zum Beispiel
     *   k = 1: ...
     *   k = 2: ...
     *
     * @param geheimtext der abgefangene Geheimtext
     */
    public void bruteForce(String geheimtext)
    {
        // TODO EXPERTE
    }

    /**
     * Fuer Mission 3 (Haeufigkeitsanalyse): Zaehlt, wie oft jeder Buchstabe vorkommt.
     * anzahl[0] ist die Anzahl von 'A', anzahl[1] die von 'B', ... anzahl[25] die von 'Z'.
     *
     * @param text ein Text in Grossbuchstaben
     * @return ein Array mit 26 Zaehlern
     */
    public int[] zaehleBuchstaben(String text)
    {
        int[] anzahl = new int[26];
        // TODO EXPERTE
        return anzahl;
    }
}
