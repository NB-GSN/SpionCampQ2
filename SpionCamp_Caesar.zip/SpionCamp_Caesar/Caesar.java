/**
 * SpionCamp "Tatort Schulnetz" - Mission 2: Java-Labor
 *
 * Die Klasse Caesar ver- und entschluesselt Texte mit dem Caesar-Verfahren.
 * Es werden nur Grossbuchstaben A bis Z verschoben. Leerzeichen bleiben gleich.
 *
 * LUECKENTEXT: An jeder Stelle mit einem Kommentar L1, L2, ... steht ein
 * Platzhalter (z. B. 0 oder '?'). Ersetzt den Platzhalter durch den richtigen Code.
 * Die Kommentare koennt ihr stehen lassen.
 *
 * Auf der Camp-Seite (Mission 2) koennt ihr jede Luecke vorher pruefen
 * und zu jeder Luecke eine Hilfe aufrufen.
 *
 * Testen: Rechtsklick auf die Klasse Pruefstand und
 * pruefeBasis(), pruefeStandard() oder pruefeExperte() aufrufen.
 *
 * @author Forensik-Team ...........
 * @version 2.0
 */
public class Caesar
{
    // ===================== Stufe BASIS: Luecken L1 bis L3 =====================

    /**
     * Verschiebt einen einzelnen Grossbuchstaben um k Stellen im Alphabet.
     * Beispiel: verschluesseln('H', 3) liefert 'K', verschluesseln('Z', 3) liefert 'C'.
     */
    public char verschluesseln(char c, int k)
    {
        int nummer = c - '?' /* L1 */;                    // Buchstabe -> Zahl von 0 bis 25
        int neueNummer = (nummer + 0 /* L2 */) % 1 /* L3 */;   // verschieben, nach Z wieder bei A
        return (char) ('A' + neueNummer);                 // Zahl -> Buchstabe
    }

    // ===================== Stufe STANDARD: Luecken L4 bis L8 =====================

    /**
     * Verschluesselt einen ganzen Text mit dem Schluessel k.
     * Beispiel: verschluesselnText("INFORMATIK", 3) liefert "LQIRUPDWLN".
     */
    public String verschluesselnText(String text, int k)
    {
        String ergebnis = "";
        for (int i = 0; i < 0 /* L4 */; i++) {
            char zeichen = text.charAt(0 /* L5 */);
            if (zeichen >= 'A' && zeichen <= '?' /* L6 */) {
                ergebnis = ergebnis + verschluesseln(zeichen, 0 /* L7 */);
            } else {
                ergebnis = ergebnis + "" /* L8 */;
            }
        }
        return ergebnis;
    }

    // ===================== Stufe EXPERTE: Luecken L9 bis L12 =====================

    /**
     * Entschluesselt einen Geheimtext, wenn der Schluessel k bekannt ist.
     */
    public String entschluesselnText(String geheimtext, int k)
    {
        return verschluesselnText(geheimtext, 0 /* L9 */);
    }

    /**
     * Brute-Force-Angriff: Gibt fuer jeden Schluessel von 1 bis 25 eine Zeile aus.
     */
    public void bruteForce(String geheimtext)
    {
        for (int k = 1; k <= 0 /* L10 */; k++) {
            System.out.println("k = " + k + ": " + "" /* L11 */);
        }
    }

    /**
     * Zaehlt, wie oft jeder Buchstabe vorkommt.
     * anzahl[0] ist die Anzahl von 'A', anzahl[1] die von 'B', ... anzahl[25] die von 'Z'.
     */
    public int[] zaehleBuchstaben(String text)
    {
        int[] anzahl = new int[26];
        for (int i = 0; i < text.length(); i++) {
            char zeichen = text.charAt(i);
            if (zeichen >= 'A' && zeichen <= 'Z') {
                anzahl[0 /* L12 */]++;
            }
        }
        return anzahl;
    }
}
