SpionCamp "Tatort Schulnetz" - Mission 2: Java-Labor Caesar
============================================================

Ziel: Vervollstaendigt die Klasse Caesar und entschluesselt damit die
abgefangenen Nachrichten der Taeter.

So geht ihr vor:
1. Oeffnet die Klasse Caesar (Doppelklick).
2. Im Code stehen Platzhalter mit einem Kommentar L1, L2, ... L12.
   Ersetzt jeden Platzhalter durch den richtigen Code.
   Auf der Camp-Seite (Mission 2) koennt ihr jede Luecke vorher pruefen
   und Hilfen aufrufen.
3. Uebersetzen, dann Rechtsklick auf Pruefstand:
   Basis    (L1-L3)   -> pruefeBasis()
   Standard (L4-L8)   -> pruefeStandard()
   Experte  (L9-L12)  -> pruefeExperte()

Transferaufgabe (nach Mission 4): Klasse Vigenere selbst programmieren,
   ohne Luecken. Pruefen mit Pruefstand -> pruefeVigenere().

Beweisstuecke: In der Klasse Beweismittel stehen die abgefangenen Nachrichten.
Beim Methodenaufruf koennt ihr als Parameter z. B. Beweismittel.NACHRICHT_2
eintragen.

Camp-Seite: https://nb-gsn.github.io/SpionCampQ2/
