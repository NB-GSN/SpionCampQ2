/**
 * SpionCamp "Tatort Schulnetz" - Transferaufgabe: Vigenere selbst programmieren
 *
 * Vigenere ist Caesar mit wechselndem Schluessel: Jeder Buchstabe des
 * Schluesselworts gibt eine eigene Verschiebung an (A = 0, B = 1, ... Z = 25).
 * Das Schluesselwort wird immer wiederholt. Leerzeichen bleiben erhalten und
 * verbrauchen KEINEN Buchstaben des Schluesselworts.
 *
 * Diesmal gibt es keine Luecken. Hilfen in mehreren Stufen findet ihr auf der
 * Camp-Seite (Mission 4, Transferaufgabe). Testen: Pruefstand.pruefeVigenere()
 *
 * @author Forensik-Team ...........
 * @version 1.0
 */
public class Vigenere
{
    private Caesar caesar = new Caesar();   // eure Caesar-Klasse darf mitbenutzt werden

    /**
     * Verschluesselt einen Text mit dem Schluesselwort.
     * Beispiel: verschluesseln("ANANAS", "KEY") liefert "KRYXEQ".
     *
     * @param text Klartext in Grossbuchstaben, Leerzeichen erlaubt
     * @param schluessel Schluesselwort in Grossbuchstaben, z. B. "ROUTER"
     * @return der Geheimtext
     */
    public String verschluesseln(String text, String schluessel)
    {
        // TODO TRANSFER
        return "";
    }

    /**
     * Entschluesselt einen Geheimtext mit dem Schluesselwort.
     * Beispiel: entschluesseln("KRYXEQ", "KEY") liefert "ANANAS".
     *
     * @param geheimtext Geheimtext in Grossbuchstaben, Leerzeichen erlaubt
     * @param schluessel Schluesselwort in Grossbuchstaben
     * @return der Klartext
     */
    public String entschluesseln(String geheimtext, String schluessel)
    {
        // TODO TRANSFER
        return "";
    }
}
